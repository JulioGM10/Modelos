//
//  CPViewController.swift
//  carritoCer
//
//  Created by macbook on 3/19/19.
//  Copyright © 2019 Organization. All rights reserved.
//

import UIKit

class CPViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{

    @IBOutlet weak var TotalCuenta: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        TotalCuenta.text = "Total a pagar: $\(String(cuentaTotal))"
    }
    
    
    //se generan las celdas para mostrar los producto que se quieren comprar
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaProductos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "celdaCuenta"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! TableViewCell2
        
        cell.textLabel?.text = listaProductos[indexPath.row].nombre
        cell.cantidadLabel.text = String (listaProductos[indexPath.row].cantidad)
        cell.precioLabel.text = "$\(String (listaProductos[indexPath.row].precioTotal))"
        
        return cell
    }
    
    @IBAction func PagarCuenta(_ sender: UIButton) {
        
        let menu = UIAlertController(title: "Cuenta Pagada", message: "Gracias por comprar en lamasverga.com ;)", preferredStyle: .alert)
        
        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
        
        menu.addAction(ok)
        present(menu, animated: true, completion: nil)
    }
    


}
