//
//  TableViewCell2.swift
//  carritoCer
//
//  Created by macbook on 3/19/19.
//  Copyright © 2019 Organization. All rights reserved.
//

import UIKit

class TableViewCell2: UITableViewCell {

    @IBOutlet var cantidadLabel: UILabel!
    @IBOutlet var precioLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
      
    }

}
