//
//  ListaProductos.swift
//  carritoCer
//
//  Created by macbook on 3/19/19.
//  Copyright © 2019 Organization. All rights reserved.
//

import Foundation
import UIKit

struct ProductoComprado {
    var nombre: String
    var precioTotal: Double
    var cantidad: Int
}

var cuentaTotal: Double = 0.0
var listaProductos: [ProductoComprado] = []
