//
//  Producto.swift
//  carritoCer
//
//  Created by macbook on 3/19/19.
//  Copyright © 2019 Organization. All rights reserved.
//

import Foundation

struct Producto{
    var nombre: String
    var desc: String
    var precio: Double
    var imagen: String
}

var IndexP = 0

let Tq = Producto(nombre: "Tequila", desc: "Rancho escondido 500 ml", precio: 200, imagen: "Teq")

let Wk = Producto(nombre:"Whisky", desc: "Red labe de 650 ml ", precio: 400, imagen: "whis")

let Vk = Producto(nombre: "Vodaka", desc: "Oso Negro 1L", precio: 120, imagen: "Vk")

let Cv = Producto(nombre: "Cervesa", desc: "XX 350 ml", precio: 20, imagen: "Cv")



var cervezas = [Tq,Wk,Vk,Cv]
